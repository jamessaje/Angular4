export class MenuItem
{
    private itemCode:number;
    private itemName:string;
    constructor(code:number,name:string)
    {
        this.itemCode=code;
        this.itemName=name;
    }
}