import {MenuItem} from "../models/menuitem";

export var menuData:MenuItem[]=[new MenuItem(1,"Claim_Intimation"),
    new MenuItem(2,"Assessor_Report"),
    new MenuItem(3,"Payment"),
    new MenuItem(4,"Claim_Approval")

];