import {Injectable} from "@angular/core";
import {MenuItem} from "../models/menuitem";
import {menuData} from "./menuitemdata";

@Injectable()
export class MenuService{

    public getMenuData():MenuItem[]
    {
        return menuData;
    }



}