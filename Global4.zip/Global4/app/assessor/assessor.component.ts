import {Component} from "@angular/core";

@Component({
   selector:'assessor-report',
    templateUrl:'./app/assessor/assessor.component.html',
    styleUrls:['./app/assessor/assessor.component.css']
})
export class AssessorComponent
{




}