import {Component, OnInit,Inject} from "@angular/core";
import {PolicyService} from "../services/policyservice";
import {MatRadioModule} from '@angular/material/radio';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
@Component({
    selector:'payment',
    templateUrl:'./app/payment/payment.component.html',
    styleUrls:['./app/payment/payment.component.css']
})
export class PaymentComponent implements OnInit
{

  private policies:any;
  private selectedMode:string="Cheque";
  private  amount: number;
  private  chequeNo: number;
     paymentOptions:string[] = [
        'Cheque',
        'Cash'
    ];

  constructor(private policyService:PolicyService,private matDialog:MatDialog)
  {

  }

  ngOnInit()
  {
      this.policies=this.policyService.getPolicies();
  }


  openDialog(value)
  {
      if(value!=='undefined') {
          console.log("clicked..." + value);
          if(value=="Cheque") {
              let dialogRef = this.matDialog.open(DialogOverviewExampleDialog, {
                  width: '250px',
                  data: {chequeNo:this.chequeNo,amount: this.amount,}
              });
              dialogRef.afterClosed().subscribe(result => {
                  console.log('The dialog was closed');
                  this.amount = result;
              });
          }
          if(value=="Cash")
          {
              let dialogRef = this.matDialog.open(DialogOverviewExampleDialog, {
                  width: '250px',
                  data: {amount: this.amount,}
              });
              dialogRef.afterClosed().subscribe(result => {
                  console.log('The dialog was closed');
                  this.amount = result;
              });
          }

      }


  }

}


@Component({
    selector: 'dialog-overview-example-dialog',
    templateUrl: './app/payment/dialog-overview-example-dialog.html',
})
export class DialogOverviewExampleDialog {

    constructor(
        public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    onNoClick(): void {
        this.dialogRef.close();
    }

}