export interface marker{
    name:string;
    lat:number;
    lng:number;
}